import os
import unittest

from tests import helpers as _helpers
from tests.helpers import *


class ClientHashtagReusableSessionLiveTestCase(unittest.TestCase):
    def live_client(self):
        if not TEST_ACCOUNTS_URL:
            self.skipTest("TEST_ACCOUNTS_URL is required for reusable hashtag live tests")
        last_error = None
        for account in _helpers.fetch_test_accounts(count=20):
            try:
                cl = Client(settings=dict(account["client_settings"]), proxy=os.getenv("IG_PROXY") or account["proxy"])
                cl._user_id = account.get("user_id")
                cl.hashtag_info("instagram")
                return cl
            except Exception as exc:
                last_error = f"{type(exc).__name__}: {str(exc)[:120]}"
        self.skipTest(f"Could not build a usable hashtag test client: {last_error}")

    def test_hashtag_medias_paginated_recent_live(self):
        cl = self.live_client()

        medias, max_id = cl.hashtag_medias_paginated("instagram", amount=12, tab_key="recent")
        self.assertGreater(len(medias), 0)
        self.assertLessEqual(len(medias), 12)
        self.assertIsInstance(medias[0], Media)
        if not max_id:
            self.skipTest("instagram hashtag did not return next cursor")

        next_medias, next_max_id = cl.hashtag_medias_paginated(
            "instagram",
            amount=12,
            tab_key="recent",
            end_cursor=max_id,
        )

        self.assertGreater(len(next_medias), 0)
        self.assertNotEqual(max_id, next_max_id)
        self.assertTrue({media.pk for media in medias}.isdisjoint({media.pk for media in next_medias}))

    def test_iter_hashtag_medias_recent_live(self):
        cl = self.live_client()

        medias = list(cl.iter_hashtag_medias("instagram", amount=5, page_size=2, tab_key="recent"))

        self.assertEqual(len(medias), 5)
        self.assertIsInstance(medias[0], Media)
        self.assertEqual(len({media.pk for media in medias}), len(medias))


class ClientHashtagTestCase(_helpers.ClientPrivateTestCase):
    REQUIRED_MEDIA_FIELDS = [
        "pk",
        "taken_at",
        "id",
        "media_type",
        "code",
        "thumbnail_url",
        "like_count",
        "caption_text",
        "video_url",
        "view_count",
        "video_duration",
        "title",
    ]

    def test_hashtag_info(self):
        hashtag = self.cl.hashtag_info("instagram")
        self.assertIsInstance(hashtag, Hashtag)
        self.assertEqual("instagram", hashtag.name)

    def test_extract_hashtag_info(self):
        hashtag = self.cl.hashtag_info("instagram")
        hashtag_v1 = self.cl.hashtag_info_v1("instagram")
        self.assertIsInstance(hashtag, Hashtag)
        self.assertIsInstance(hashtag_v1, Hashtag)
        self.assertEqual("instagram", hashtag.name)
        self.assertEqual(hashtag.id, hashtag_v1.id)
        self.assertEqual(hashtag.name, hashtag_v1.name)
        self.assertGreater(hashtag.media_count, 0)
        self.assertGreater(hashtag_v1.media_count, 0)

    def test_hashtag_medias_top(self):
        medias = self.cl.hashtag_medias_top("instagram", amount=2)
        self.assertEqual(len(medias), 2)
        self.assertIsInstance(medias[0], Media)

    def test_extract_hashtag_medias_top(self):
        medias = self.cl.hashtag_medias_top("instagram", amount=9)
        medias_v1 = self.cl.hashtag_medias_top_v1("instagram", amount=9)
        self.assertEqual(len(medias), 9)
        self.assertIsInstance(medias[0], Media)
        self.assertEqual(len(medias_v1), 9)
        self.assertIsInstance(medias_v1[0], Media)

    def test_hashtag_medias_recent(self):
        medias = self.cl.hashtag_medias_recent("instagram", amount=2)
        self.assertEqual(len(medias), 2)
        self.assertIsInstance(medias[0], Media)

    def test_extract_hashtag_medias_recent(self):
        medias_v1 = self.cl.hashtag_medias_recent_v1("instagram", amount=31)
        medias = self.cl.hashtag_medias_recent("instagram", amount=31)
        self.assertEqual(len(medias), 31)
        self.assertIsInstance(medias[0], Media)
        self.assertEqual(len(medias_v1), 31)
        self.assertIsInstance(medias_v1[0], Media)
        for media in [*medias[:10], *medias_v1[:10]]:
            data = media.model_dump()
            for f in self.REQUIRED_MEDIA_FIELDS:
                self.assertIn(f, data)
            self.assertTrue(data["pk"])
            self.assertTrue(data["id"])
            self.assertTrue(data["code"])
            self.assertTrue(data["media_type"])

    def test_hashtag_medias_recent_v1_chunk_paginates_live(self):
        medias, max_id = self.cl.hashtag_medias_v1_chunk("instagram", max_amount=12, tab_key="recent")
        self.assertGreater(len(medias), 0)
        self.assertIsInstance(medias[0], Media)
        if not max_id:
            self.skipTest("instagram hashtag did not return next_max_id")

        next_medias, next_max_id = self.cl.hashtag_medias_v1_chunk(
            "instagram",
            max_amount=12,
            tab_key="recent",
            max_id=max_id,
        )

        self.assertGreater(len(next_medias), 0)
        self.assertNotEqual(max_id, next_max_id)
        self.assertTrue({media.pk for media in medias}.isdisjoint({media.pk for media in next_medias}))

    def test_hashtag_following(self):
        hashtags = self.cl.hashtag_following(amount=1)
        self.assertIsInstance(hashtags, list)
        if hashtags:
            self.assertIsInstance(hashtags[0], Hashtag)
            self.assertTrue(hashtags[0].id)
            self.assertTrue(hashtags[0].name)
