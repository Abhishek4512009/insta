from instagrapi.exceptions import (
    ClientForbiddenError,
    ClientThrottledError,
    ClipNotUpload,
    LoginRequired,
    PhotoNotUpload,
    PleaseWaitFewMinutes,
)
from tests import helpers as _helpers
from tests.helpers import *


class ClientMediaTestCase(_helpers.ClientPrivateTestCase):
    def test_media_id(self):
        self.assertEqual(self.cl.media_id(3258619191829745894), "3258619191829745894_25025320")

    def test_media_info(self):
        media = self.cl.media_info(3258619191829745894)
        self.assertIsInstance(media, Media)
        self.assertEqual(str(media.pk), "3258619191829745894")
        self.assertEqual(media.id, "3258619191829745894_25025320")
        self.assertEqual(media.user.pk, "25025320")
        self.assertEqual(media.user.username, "instagram")
        self.assertTrue(str(media.thumbnail_url).startswith("https://"))

    def test_media_pk(self):
        self.assertEqual(self.cl.media_pk("2154602296692269830_25025320"), "2154602296692269830")

    def test_media_pk_from_code(self):
        self.assertEqual(self.cl.media_pk_from_code("B-fKL9qpeab"), "2278584739065882267")
        self.assertEqual(
            self.cl.media_pk_from_code("B8jnuB2HAbyc0q001y3F9CHRSoqEljK_dgkJjo0"),
            "2243811726252050162",
        )

    def test_code_from_media_pk(self):
        self.assertEqual(self.cl.media_code_from_pk(2278584739065882267), "B-fKL9qpeab")
        self.assertEqual(self.cl.media_code_from_pk(2243811726252050162), "B8jnuB2HAby")

    def test_media_pk_from_url(self):
        self.assertEqual(
            self.cl.media_pk_from_url("https://instagram.com/p/B1LbfVPlwIA/"),
            "2110901750722920960",
        )
        self.assertEqual(
            self.cl.media_pk_from_url("https://www.instagram.com/p/B-fKL9qpeab/?igshid=1xm76zkq7o1im"),
            "2278584739065882267",
        )


class ClientMediaExtendTestCase(_helpers.ClientPrivateTestCase):
    def __init__(self, *args, **kwargs):
        self.cl = None
        return unittest.TestCase.__init__(self, *args, **kwargs)

    def test_media_user(self):
        user = self.cl.media_user(2154602296692269830)
        self.assertIsInstance(user, UserShort)
        for key, val in {
            "pk": "25025320",
            "username": "instagram",
            "full_name": "Instagram",
            "is_private": False,
        }.items():
            self.assertEqual(getattr(user, key), val)
        self.assertTrue(user.profile_pic_url.startswith("https://"))

    def test_media_oembed(self):
        media_oembed = self.cl.media_oembed("https://www.instagram.com/p/B3mr1-OlWMG/")
        self.assertIsInstance(media_oembed, MediaOembed)
        for key, val in {
            "title": "В гостях у ДК @delai_krasivo_kaifui",
            "author_name": "instagram",
            "author_url": "https://www.instagram.com/instagram",
            "author_id": "25025320",
            "media_id": "2154602296692269830_25025320",
            "width": 658,
            "height": None,
            "thumbnail_width": 640,
            "thumbnail_height": 480,
            "can_view": True,
        }.items():
            self.assertEqual(getattr(media_oembed, key), val)
        self.assertTrue(media_oembed.thumbnail_url.startswith("http"))

    def test_media_likers(self):
        media = self.cl.user_medias(self.cl.user_id, amount=3)[-1]
        self.assertIsInstance(media, Media)
        likers = self.cl.media_likers(media.pk)
        self.assertTrue(len(likers) > 0)
        self.assertIsInstance(likers[0], UserShort)

    def test_media_like_by_pk(self):
        user_id = self.user_id_from_username("instagram")
        media = self.cl.user_medias_v1(user_id, amount=1)[0]
        try:
            self.assertTrue(self.cl.media_like(media.pk))
        finally:
            self.cl.media_unlike(media.pk)

    def test_media_edit(self):
        # Upload photo
        path = self.copy_media_fixture("examples/kanada.jpg")
        self.assertIsInstance(path, Path)
        media = None
        try:
            msg = "Test caption for photo"
            media = self.cl.photo_upload(path, msg)
            self.assertIsInstance(media, Media)
            self.assertEqual(media.caption_text, msg)
            self.assertUploadedMediaAccessible(media, media_type=1, caption_text=msg)
            # Change caption
            msg = "New caption %s" % random.randint(1, 100)
            self.cl.media_edit(media.pk, msg)
            media = self.cl.media_info(media.pk)
            self.assertIsInstance(media, Media)
            self.assertEqual(media.caption_text, msg)
            self.assertTrue(self.cl.media_delete(media.pk))
            media = None
        finally:
            if media:
                self.cl.media_delete(media.id)

    def test_media_edit_igtv(self):
        path = self.make_video_fixture(label="IGTV edit fixture", duration=61)
        self.assertIsInstance(path, Path)
        media = None
        try:
            try:
                media = self.cl.igtv_upload(path, "Test title", "Test caption for IGTV")
            except RetryError as exc:
                if "configure_to_igtv" in str(exc) and "500 error responses" in str(exc):
                    self.skipTest("Instagram returned server 500 for configure_to_igtv")
                raise
            self.assertIsInstance(media, Media)
            self.assertUploadedMediaAccessible(
                media, media_type=2, caption_text="Test caption for IGTV", title="Test title"
            )
            # Enter title
            title = "Title %s" % random.randint(1, 100)
            msg = "New caption %s" % random.randint(1, 100)
            self.cl.media_edit(media.pk, msg, title)
            media = self.cl.media_info(media.pk)
            self.assertIsInstance(media, Media)
            self.assertEqual(media.title, title)
            self.assertEqual(media.caption_text, msg)
            # Split caption to title and caption
            title = "Title %s" % random.randint(1, 100)
            msg = "New caption %s" % random.randint(1, 100)
            self.cl.media_edit(media.pk, f"{title}\n{msg}")
            media = self.cl.media_info(media.pk)
            self.assertIsInstance(media, Media)
            self.assertEqual(media.title, title)
            self.assertEqual(media.caption_text, msg)
            # Empty title (duplicate one-line caption)
            msg = "New caption %s" % random.randint(1, 100)
            self.cl.media_edit(media.pk, msg, "")
            media = self.cl.media_info(media.pk)
            self.assertIsInstance(media, Media)
            self.assertEqual(media.title, msg)
            self.assertEqual(media.caption_text, msg)
            self.assertTrue(self.cl.media_delete(media.id))
            media = None
        finally:
            if media:
                self.cl.media_delete(media.id)

    def test_media_like_and_unlike(self):
        user_id = self.user_id_from_username("instagram")
        media = self.cl.user_medias_v1(user_id, amount=1)[0]
        media_pk = media.pk
        self.assertTrue(self.cl.media_unlike(media.id))
        # like
        self.assertTrue(self.cl.media_like(media.id))
        media = self.cl.media_info_v1(media_pk)  # refresh after like
        self.assertTrue(media.has_liked)
        # unlike
        self.assertTrue(self.cl.media_unlike(media.id))
        media = self.cl.media_info_v1(media_pk)  # refresh after unlike
        self.assertFalse(media.has_liked)

    def test_media_note_create_and_delete(self):
        user_id = self.user_id_from_username("instagram")
        media = self.cl.user_medias_v1(user_id, amount=1)[0]
        note = None
        try:
            note = self.cl.media_note_create(media.id, text="")
            self.assertEqual(note.get("status"), "ok")
            self.assertTrue(note.get("id"))
            self.assertEqual(note.get("text"), "")
        finally:
            if note and note.get("id"):
                self.assertTrue(self.cl.media_note_delete(note["id"]))


class ClientLinkedReelLiveTestCase(_helpers.ClientPrivateTestCase):
    def __init__(self, *args, **kwargs):
        self.cl = None
        self.clients = []
        return unittest.TestCase.__init__(self, *args, **kwargs)

    def setup_method(self, *args, **kwargs):
        return None

    def setUp(self):
        if not TEST_ACCOUNTS_URL:
            self.skipTest("TEST_ACCOUNTS_URL is required for linked Reel live tests")
        try:
            self.clients = self.fresh_accounts(10)
        except RuntimeError as exc:
            self.skipTest(str(exc))

    def make_cover_fixture(self, color):
        try:
            from PIL import Image
        except ImportError:
            self.skipTest("Pillow is required to generate a linked Reel cover fixture")

        with tempfile.NamedTemporaryFile(delete=False, suffix=".jpg") as tmp:
            path = Path(tmp.name)
        self.addCleanup(lambda: path.unlink(missing_ok=True))
        Image.new("RGB", (720, 1280), color).save(path, quality=95)
        return path

    def cleanup_uploaded_media(self, media):
        if not media:
            return
        try:
            self.assertTrue(self.cl.media_delete(media.id))
        except Exception as exc:
            print(f"Linked Reel cleanup media_delete failed: {exc.__class__.__name__} {exc}")

    def run_media_link_reel(self, client, origin_path, target_path, origin_cover, target_cover):
        self.cl = client
        origin = None
        target = None
        try:
            timestamp = int(time.time())
            target = self.cl.clip_upload(target_path, f"Linked Reel target {timestamp}", thumbnail=target_cover)
            self.assertUploadedMediaAccessible(
                target,
                media_type=2,
                product_type="clips",
                caption_text=f"Linked Reel target {timestamp}",
            )
            origin = self.cl.clip_upload(origin_path, f"Linked Reel origin {timestamp}", thumbnail=origin_cover)
            self.assertUploadedMediaAccessible(
                origin,
                media_type=2,
                product_type="clips",
                caption_text=f"Linked Reel origin {timestamp}",
            )

            self.assertTrue(self.cl.media_link_reel(origin.id, target.id, link_name="Watch Next"))
        finally:
            for media in (origin, target):
                self.cleanup_uploaded_media(media)

    def test_media_link_reel(self):
        origin_path = self.make_video_fixture(label="linked Reel origin fixture", color="blue")
        target_path = self.make_video_fixture(label="linked Reel target fixture", color="red")
        origin_cover = self.make_cover_fixture("blue")
        target_cover = self.make_cover_fixture("red")
        self.assertIsInstance(origin_path, Path)
        self.assertIsInstance(target_path, Path)
        self.assertIsInstance(origin_cover, Path)
        self.assertIsInstance(target_cover, Path)

        upload_failures = {}
        for client in self.clients:
            try:
                self.run_media_link_reel(client, origin_path, target_path, origin_cover, target_cover)
                return
            except (
                ClipNotUpload,
                PhotoNotUpload,
                LoginRequired,
                PleaseWaitFewMinutes,
                ClientThrottledError,
                RetryError,
            ) as exc:
                upload_failures[exc.__class__.__name__] = upload_failures.get(exc.__class__.__name__, 0) + 1
                continue

        self.skipTest(f"No linked Reel upload-capable test account was available (upload_failures={upload_failures})")


class ClientCompareExtractTestCase(_helpers.ClientPrivateTestCase):
    def assertLocation(self, v1, gql):
        if not isinstance(v1, dict):
            return self.assertEqual(v1, gql)
        for key, val in v1.items():
            if key == "external_id":
                continue  # id may differ
            gql_val = gql[key]
            if isinstance(val, float):
                val, gql_val = round(val, 4), round(gql_val, 4)
            self.assertEqual(val, gql_val)

    def assertMedia(self, v1, gql):
        self.assertTrue(v1.pop("comment_count") <= gql.pop("comment_count"))
        self.assertLocation(v1.pop("location"), gql.pop("location"))
        v1.pop("has_liked")
        gql.pop("has_liked")
        for key in (
            "caption_is_edited",
            "dimensions",
            "has_audio",
            "like_and_view_counts_disabled",
            "viewer_can_reshare",
            "viewer_has_saved",
            "is_paid_partnership",
            "is_affiliate",
            "dash_info",
            "clips_music_attribution_info",
            "comments_preview",
            "hoisted_comments",
        ):
            v1.pop(key)
            gql.pop(key)
        self.assertDictEqual(v1, gql)

    def media_info(self, media_pk):
        media_v1 = self.cl.media_info_v1(media_pk)
        self.assertIsInstance(media_v1, Media)
        media_gql = self.cl.media_info_gql(media_pk)
        self.assertIsInstance(media_gql, Media)
        return media_v1.dict(), media_gql.dict()

    def test_two_extract_media_photo(self):
        media_v1, media_gql = self.media_info(self.cl.media_pk_from_code("B3mr1-OlWMG"))
        self.assertTrue(media_v1.pop("thumbnail_url").startswith("https://"))
        self.assertTrue(media_gql.pop("thumbnail_url").startswith("https://"))
        self.assertMedia(media_v1, media_gql)

    def test_two_extract_media_video(self):
        media_v1, media_gql = self.media_info(self.cl.media_pk_from_code("B3rFQPblq40"))
        self.assertTrue(media_v1.pop("video_url").startswith("https://"))
        self.assertTrue(media_gql.pop("video_url").startswith("https://"))
        self.assertTrue(media_v1.pop("thumbnail_url").startswith("https://"))
        self.assertTrue(media_gql.pop("thumbnail_url").startswith("https://"))
        self.assertMedia(media_v1, media_gql)

    def test_two_extract_media_album(self):
        media_v1, media_gql = self.media_info(self.cl.media_pk_from_code("BjNLpA1AhXM"))
        for res in media_v1["resources"]:
            self.assertTrue(res.pop("thumbnail_url").startswith("https://"))
            if res["media_type"] == 2:
                self.assertTrue(res.pop("video_url").startswith("https://"))
        for res in media_gql["resources"]:
            self.assertTrue(res.pop("thumbnail_url").startswith("https://"))
            if res["media_type"] == 2:
                self.assertTrue(res.pop("video_url").startswith("https://"))
        self.assertMedia(media_v1, media_gql)

    def test_two_extract_media_igtv(self):
        media_v1, media_gql = self.media_info(self.cl.media_pk_from_code("ByYn5ZNlHWf"))
        self.assertTrue(media_v1.pop("video_url").startswith("https://"))
        self.assertTrue(media_gql.pop("video_url").startswith("https://"))
        self.assertTrue(media_v1.pop("thumbnail_url").startswith("https://"))
        self.assertTrue(media_gql.pop("thumbnail_url").startswith("https://"))
        self.assertMedia(media_v1, media_gql)

    def test_two_extract_user(self):
        user_v1 = self.cl.user_info_v1(25025320)
        user_gql = self.cl.user_info_gql(25025320)
        self.assertIsInstance(user_v1, User)
        self.assertIsInstance(user_gql, User)
        user_v1, user_gql = user_v1.dict(), user_gql.dict()
        self.assertTrue(user_v1.pop("profile_pic_url").startswith("https://"))
        self.assertTrue(user_gql.pop("profile_pic_url").startswith("https://"))
        self.assertDictEqual(user_v1, user_gql)


class ClientMediaCountAliasLiveTestCase(unittest.TestCase):
    def setUp(self):
        if not TEST_ACCOUNTS_URL:
            self.skipTest("TEST_ACCOUNTS_URL is required for media count alias live tests")
        try:
            self.cl = _helpers.fresh_test_account(count=20, attempts=20)
        except RuntimeError as exc:
            self.skipTest(str(exc))

    def test_media_info_gql_normalizes_live_video_count_aliases(self):
        code = "C_BM2yAN4Rm"
        media_pk = self.cl.media_pk_from_code(code)
        captured_payload = {}
        original_doc_id_request = self.cl.public_doc_id_graphql_request

        def capture_doc_id_payload(*args, **kwargs):
            result = original_doc_id_request(*args, **kwargs)
            payload = result.get("xdt_shortcode_media") or result.get("shortcode_media")
            if payload:
                captured_payload.update(payload)
            return result

        with (
            mock.patch.object(
                self.cl,
                "public_graphql_request",
                side_effect=ClientForbiddenError("force doc_id media fallback"),
            ),
            mock.patch.object(self.cl, "public_doc_id_graphql_request", side_effect=capture_doc_id_payload),
        ):
            media = self.cl.media_info_gql(media_pk)

        self.assertTrue(captured_payload, "public doc_id media payload was empty")
        self.assertIn(captured_payload.get("__typename"), {"GraphVideo", "XDTGraphVideo"})
        self.assertIn("video_view_count", captured_payload)
        self.assertIn("video_play_count", captured_payload)
        self.assertEqual(media.view_count, captured_payload["video_view_count"])
        self.assertEqual(media.play_count, captured_payload["video_play_count"])


class ClientClipSeenLiveTestCase(unittest.TestCase):
    def live_client(self):
        if not TEST_ACCOUNTS_URL:
            self.skipTest("TEST_ACCOUNTS_URL is required for clip seen live tests")
        last_error = None
        for account in _helpers.fetch_test_accounts(count=20, timeout=30):
            try:
                cl = _helpers.client_from_test_account(account)
                cl.request_timeout = 0
                return cl
            except Exception as exc:
                last_error = f"{type(exc).__name__}: {str(exc)[:120]}"
        self.skipTest(f"Could not login with any test account: {last_error}")

    def test_clip_seen_live(self):
        cl = self.live_client()
        try:
            medias = cl.user_clips_v1("25025320", amount=3)
        except Exception as exc:
            self.skipTest(f"Could not fetch public Instagram clips: {type(exc).__name__}: {str(exc)[:120]}")
        if not medias:
            self.skipTest("Public Instagram clips feed returned no media")

        self.assertTrue(cl.clip_seen([medias[0].id]))


class ClientExtractTestCase(_helpers.ClientPrivateTestCase):
    def test_extract_media_photo(self):
        media_pk = self.cl.media_pk_from_url("https://www.instagram.com/p/B3mr1-OlWMG/")
        media = self.cl.media_info(media_pk)
        self.assertIsInstance(media, Media)
        self.assertTrue(len(media.resources) == 0)
        self.assertTrue(media.comment_count > 5)
        self.assertTrue(media.like_count > 80)
        for key, val in {
            "caption_text": "В гостях у ДК @delai_krasivo_kaifui",
            "thumbnail_url": "https://",
            "pk": "2154602296692269830",
            "code": "B3mr1-OlWMG",
            "media_type": 1,
            "taken_at": datetime(2019, 10, 14, 15, 57, 10, tzinfo=UTC()),
        }.items():
            if isinstance(val, str):
                self.assertTrue(getattr(media, key).startswith(val))
            else:
                self.assertEqual(getattr(media, key), val)
        for key, val in {"pk": "25025320", "username": "instagram"}.items():
            self.assertEqual(getattr(media.user, key), val)

    def test_extract_media_video(self):
        media_pk = self.cl.media_pk_from_url("https://www.instagram.com/p/BgRIGUQFltp/")
        media = self.cl.media_info(media_pk)
        self.assertIsInstance(media, Media)
        self.assertTrue(len(media.resources) == 0)
        self.assertTrue(media.view_count > 150)
        self.assertTrue(media.comment_count > 1)
        self.assertTrue(media.like_count > 40)
        for key, val in {
            "caption_text": "Веселья ради\n\n@milashensky #dowhill #skateboarding #foros #crimea",
            "pk": 1734202949948037993,
            "code": "BgRIGUQFltp",
            "video_url": "https://",
            "thumbnail_url": "https://",
            "media_type": 2,
            "taken_at": datetime(2018, 3, 13, 14, 59, 23, tzinfo=UTC()),
        }.items():
            if isinstance(val, str):
                self.assertTrue(getattr(media, key).startswith(val))
            else:
                self.assertEqual(getattr(media, key), val)
        for key, val in {"pk": "25025320", "username": "instagram"}.items():
            self.assertEqual(getattr(media.user, key), val)

    def test_extract_media_album(self):
        media_pk = self.cl.media_pk_from_url("https://www.instagram.com/p/BjNLpA1AhXM/")
        media = self.cl.media_info(media_pk)
        self.assertIsInstance(media, Media)
        self.assertTrue(len(media.resources) == 3)
        video_resource = media.resources[0]
        photo_resource = media.resources.pop()
        self.assertTrue(media.view_count == 0)
        self.assertTrue(media.comment_count == 0)
        self.assertTrue(media.like_count > 40)
        for key, val in {
            "caption_text": "@mind__flowers в Форосе под дождём, 24 мая 2018 #downhill "
            "#skateboarding #downhillskateboarding #crimea #foros #rememberwheels",
            "pk": 1787135824035452364,
            "code": "BjNLpA1AhXM",
            "media_type": 8,
            "taken_at": datetime(2018, 5, 25, 15, 46, 53, tzinfo=UTC()),
            "product_type": "",
        }.items():
            self.assertEqual(getattr(media, key), val)
        for key, val in {"pk": "25025320", "username": "instagram"}.items():
            self.assertEqual(getattr(media.user, key), val)
        for key, val in {
            "video_url": "https://",
            "thumbnail_url": "https://",
            "media_type": 2,
            "pk": 1787135361353462176,
        }.items():
            if isinstance(val, str):
                self.assertTrue(getattr(video_resource, key).startswith(val))
            else:
                self.assertEqual(getattr(video_resource, key), val)
        for key, val in {
            "video_url": None,
            "thumbnail_url": "https://",
            "media_type": 1,
            "pk": 1787133803186894424,
        }.items():
            if isinstance(val, str):
                self.assertTrue(getattr(photo_resource, key).startswith(val))
            else:
                self.assertEqual(getattr(photo_resource, key), val)

    def test_extract_media_igtv(self):
        media_pk = self.cl.media_pk_from_url("https://www.instagram.com/tv/ByYn5ZNlHWf/")
        media = self.cl.media_info(media_pk)
        self.assertIsInstance(media, Media)
        self.assertTrue(len(media.resources) == 0)
        self.assertTrue(media.view_count > 200)
        self.assertTrue(media.comment_count > 10)
        self.assertTrue(media.like_count > 50)
        for key, val in {
            "title": "zr trip, crimea, feb 2017. Edit by @milashensky",
            "caption_text": "Нашёл на диске неопубликованное в инсте произведение @milashensky",
            "pk": 2060572297417487775,
            "video_url": "https://",
            "thumbnail_url": "https://",
            "code": "ByYn5ZNlHWf",
            "media_type": 2,
            "taken_at": datetime(2019, 6, 6, 22, 22, 6, tzinfo=UTC()),
            "product_type": "igtv",
        }.items():
            if isinstance(val, str):
                self.assertTrue(getattr(media, key).startswith(val))
            else:
                self.assertEqual(getattr(media, key), val)
        for key, val in {"pk": "25025320", "username": "instagram"}.items():
            self.assertEqual(getattr(media.user, key), val)
